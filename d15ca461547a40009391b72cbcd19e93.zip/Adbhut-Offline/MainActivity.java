package com.adbhut.khata;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.math.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    SQLiteDatabase db;
    LinearLayout page, body;
    final String[] modes={"Cash","UPI","Bank"};
    final int BACKUP=101, RESTORE=102;
    final String APP="Adbhut Offline Khata";
    @Override public void onCreate(Bundle b){super.onCreate(b);
        try {
            db=openOrCreateDatabase("khata.db",MODE_PRIVATE,null);
            db.execSQL("CREATE TABLE IF NOT EXISTS bills (id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT NOT NULL, customer TEXT NOT NULL, note TEXT NOT NULL, amount INTEGER NOT NULL)");
            db.execSQL("CREATE TABLE IF NOT EXISTS entries (id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT NOT NULL, kind TEXT NOT NULL, amount INTEGER NOT NULL, mode TEXT NOT NULL, target TEXT NOT NULL DEFAULT '', bill INTEGER NOT NULL DEFAULT 0, note TEXT NOT NULL)");
            home();
        }catch(Exception e){new AlertDialog.Builder(this).setMessage("Cannot open local database: "+e.getMessage()).setPositiveButton("Close",(d,w)->finish()).show();}
    }
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(22,40,60));t.setPadding(0,dp(7),0,dp(7));return t;}
    void screen(String title){
        page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(16),dp(12),dp(16),dp(12));page.setBackgroundColor(Color.rgb(246,248,251));
        setContentView(page);page.addView(text(title,23));
        ScrollView sv=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);sv.addView(body);page.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }
    void btn(LinearLayout box,String label,Runnable task){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setOnClickListener(v->task.run());box.addView(b);}
    void line(){View v=new View(this);v.setBackgroundColor(Color.LTGRAY);body.addView(v,new LinearLayout.LayoutParams(-1,dp(1)));}
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    String money(long p){return "₹"+BigDecimal.valueOf(p,2).setScale(2).toPlainString();}
    long moneyInput(EditText e){try {long n=new BigDecimal(e.getText().toString().trim()).movePointRight(2).longValueExact();if(n<=0||n>100000000000L)throw new Exception();return n;}catch(Exception ex){throw new IllegalArgumentException("Enter a positive amount, at most 2 decimal places (maximum ₹100 crore).");}}
    String required(EditText e){String s=e.getText().toString().trim();if(s.isEmpty())throw new IllegalArgumentException("Please complete all required fields.");return s;}
    void dateCheck(String s){try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setLenient(false);if(!f.format(f.parse(s)).equals(s))throw new Exception();}catch(Exception e){throw new IllegalArgumentException("Date must be YYYY-MM-DD, e.g. "+today());}}
    EditText field(LinearLayout p,String hint,String value,boolean numeric){EditText e=new EditText(this);e.setHint(hint);e.setText(value);if(numeric)e.setInputType(8194);p.addView(e);return e;}
    Spinner select(LinearLayout p,String[] values){Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values));p.addView(s);return s;}
    LinearLayout form(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(dp(20),0,dp(20),0);return l;}
    AlertDialog dialog(String name,LinearLayout f){ScrollView sv=new ScrollView(this);sv.addView(f);AlertDialog a=new AlertDialog.Builder(this).setTitle(name).setView(sv).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();a.show();return a;}
    void error(Exception e){new AlertDialog.Builder(this).setTitle("Please check").setMessage(e.getMessage()).setPositiveButton("OK",null).show();}
    long sum(String sql,String...args){try(Cursor c=db.rawQuery(sql,args)){return c.moveToFirst()?c.getLong(0):0;}}
    long paid(long id){return sum("SELECT COALESCE(SUM(amount),0) FROM entries WHERE kind='Collection' AND bill=?",String.valueOf(id));}
    long balance(String mode){return sum("SELECT COALESCE(SUM(CASE WHEN kind IN ('Opening','Income','Collection') AND mode=? THEN amount WHEN kind='Transfer' AND target=? THEN amount WHEN kind IN ('Expense','Commission','Transfer') AND mode=? THEN -amount ELSE 0 END),0) FROM entries",mode,mode,mode);}
    void home(){screen(APP);body.addView(text("Single user • Offline • No login",14));
        long total=0;for(String m:modes)total+=balance(m);
        body.addView(text("Business balance: "+money(total),24));
        for(String m:modes)body.addView(text(m+": "+money(balance(m)),18));
        long due=sum("SELECT COALESCE(SUM(amount),0) FROM bills")-sum("SELECT COALESCE(SUM(amount),0) FROM entries WHERE kind='Collection'");
        body.addView(text("Customer due: "+money(due),20));
        body.addView(text("Expenses paid: "+money(sum("SELECT COALESCE(SUM(amount),0) FROM entries WHERE kind='Expense'")),16));
        body.addView(text("Commissions paid: "+money(sum("SELECT COALESCE(SUM(amount),0) FROM entries WHERE kind='Commission'")),16));
        btn(body,"Service bills / Record customer payment",()->bills());
        btn(body,"Add paid expense",()->entry("Expense",0));
        btn(body,"Add paid commission",()->entry("Commission",0));
        btn(body,"Add other income",()->entry("Income",0));
        btn(body,"Transfer between Cash / UPI / Bank",()->entry("Transfer",0));
        btn(body,"Enter opening balance",()->entry("Opening",0));
        btn(body,"Transaction history",()->history());
        btn(body,"Backup to a file",()->backup());
        btn(body,"Restore from a backup",()->restore());
        body.addView(text("Learning prototype. Use sample data first. No cloud sync, PIN, loans, unpaid commissions, Excel import, staff roles or GST invoices. Backup files are not encrypted; keep them private. Uninstalling or clearing app data can erase records. Opening entries are additive: enter each account's starting balance once.",14));
    }
    void bills(){screen("Service bills");btn(body,"Back to dashboard",()->home());btn(body,"+ New service bill",()->newBill());
        try(Cursor c=db.rawQuery("SELECT * FROM bills ORDER BY id DESC",null)){if(!c.moveToFirst()){body.addView(text("No bills yet. Add a sample bill to begin.",17));return;}
            do{long id=c.getLong(0),amount=c.getLong(4),p=paid(id);body.addView(text("BILL-"+(100+id)+" • "+c.getString(2),20));body.addView(text(c.getString(1)+"\n"+c.getString(3)+"\nBill "+money(amount)+" | Paid "+money(p)+"\nDue "+money(amount-p),16));if(p<amount)btn(body,"Record payment for BILL-"+(100+id),()->entry("Collection",id));line();}while(c.moveToNext());}
    }
    void newBill(){LinearLayout f=form();EditText day=field(f,"Date YYYY-MM-DD",today(),false),name=field(f,"Customer name (required)","",false),note=field(f,"Service / note","",false),amount=field(f,"Bill amount in rupees","",true);AlertDialog a=dialog("New bill (unpaid)",f);
        a.getButton(-1).setOnClickListener(v->{try{String d=required(day);dateCheck(d);String n=required(name);long amt=moneyInput(amount);ContentValues cv=new ContentValues();cv.put("day",d);cv.put("customer",n);cv.put("note",note.getText().toString());cv.put("amount",amt);db.insertOrThrow("bills",null,cv);a.dismiss();bills();}catch(Exception e){error(e);}});
    }
    void entry(String kind,long bill){LinearLayout f=form();EditText day=field(f,"Date YYYY-MM-DD",today(),false),amount=field(f,"Amount in rupees","",true);f.addView(text(kind.equals("Transfer")?"From account":"Payment account",15));Spinner mode=select(f,modes);Spinner to;
        if(kind.equals("Transfer")){f.addView(text("To account",15));to=select(f,modes);}else to=null;
        EditText note=field(f,kind.equals("Commission")?"Agent / note":"Note (optional)","",false);
        if(kind.equals("Opening"))f.addView(text("Additive opening entry. Enter a mode's opening balance only once; delete a mistaken entry from history.",14));
        AlertDialog a=dialog(kind.equals("Collection")?"Customer payment":kind,f);
        a.getButton(-1).setOnClickListener(v->{try{String d=required(day);dateCheck(d);long n=moneyInput(amount);String m=mode.getSelectedItem().toString(),t=to==null?"":to.getSelectedItem().toString();
            if(kind.equals("Transfer")&&m.equals(t))throw new IllegalArgumentException("Choose different source and destination accounts.");
            if(kind.equals("Collection")){long due=sum("SELECT amount FROM bills WHERE id=?",String.valueOf(bill))-paid(bill);if(n>due)throw new IllegalArgumentException("Payment exceeds bill due: "+money(due));}
            ContentValues cv=new ContentValues();cv.put("day",d);cv.put("kind",kind);cv.put("amount",n);cv.put("mode",m);cv.put("target",t);cv.put("bill",bill);cv.put("note",note.getText().toString());db.insertOrThrow("entries",null,cv);a.dismiss();if(bill>0)bills();else home();
        }catch(Exception e){error(e);}});
    }
    void history(){screen("Transaction history");btn(body,"Back to dashboard",()->home());body.addView(text("Negative balances are allowed so you can enter older records. Verify account balances regularly. Bills themselves appear in Service bills; this list shows account movements.",14));
        try(Cursor c=db.rawQuery("SELECT id,day,kind,amount,mode,target,bill,note FROM entries ORDER BY id DESC",null)){while(c.moveToNext()){long id=c.getLong(0),bill=c.getLong(6);String kind=c.getString(2);body.addView(text(kind+" • "+money(c.getLong(3)),19));body.addView(text(c.getString(1)+" | "+c.getString(4)+(kind.equals("Transfer")?" → "+c.getString(5):"")+(bill>0?" | BILL-"+(100+bill):"")+"\n"+c.getString(7),15));btn(body,"Delete transaction #"+id,()->new AlertDialog.Builder(this).setTitle("Delete transaction #"+id+"?").setMessage("This changes balances and cannot be undone without a backup. Bill payments become due again.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{db.delete("entries","id=?",new String[]{""+id});history();}).show());line();}}
    }
    JSONObject snapshot()throws Exception{JSONObject root=new JSONObject();root.put("app","adbhut-offline");root.put("version",1);root.put("created",today());for(String table:new String[]{"bills","entries"}){JSONArray arr=new JSONArray();try(Cursor c=db.rawQuery("SELECT * FROM "+table+" ORDER BY id",null)){while(c.moveToNext()){JSONObject row=new JSONObject();for(int i=0;i<c.getColumnCount();i++)row.put(c.getColumnName(i),c.getType(i)==Cursor.FIELD_TYPE_INTEGER?c.getLong(i):c.getString(i));arr.put(row);}}root.put(table,arr);}return root;}
    void backup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Adbhut-backup-"+today()+".json");try{startActivityForResult(i,BACKUP);}catch(Exception e){error(e);}}
    void restore(){new AlertDialog.Builder(this).setTitle("Replace all app data?").setMessage("Restore replaces all current bills and transactions. First make a backup of your current data. Only restore a backup you trust.").setNegativeButton("Cancel",null).setPositiveButton("Choose backup",(d,w)->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");try{startActivityForResult(i,RESTORE);}catch(Exception e){error(e);}}).show();}
    boolean allowed(String s,String[] a){return Arrays.asList(a).contains(s);}
    void checkBackup(JSONObject root)throws Exception{
        if(!root.getString("app").equals("adbhut-offline")||root.getInt("version")!=1)throw new Exception("Unsupported backup format.");
        JSONArray bills=root.getJSONArray("bills"),entries=root.getJSONArray("entries");Map<Long,Long> amounts=new HashMap<>(),payments=new HashMap<>();HashSet<Long> ids=new HashSet<>();
        for(int i=0;i<bills.length();i++){JSONObject b=bills.getJSONObject(i);long id=b.getLong("id"),n=b.getLong("amount");dateCheck(b.getString("day"));if(id<=0||n<=0||n>100000000000L||b.getString("customer").trim().isEmpty()||amounts.containsKey(id))throw new Exception("Invalid bill in backup.");b.getString("note");amounts.put(id,n);}
        for(int i=0;i<entries.length();i++){JSONObject e=entries.getJSONObject(i);long id=e.getLong("id"),n=e.getLong("amount"),bill=e.getLong("bill");String k=e.getString("kind"),m=e.getString("mode"),t=e.getString("target");dateCheck(e.getString("day"));e.getString("note");if(id<=0||!ids.add(id)||n<=0||n>100000000000L||!allowed(k,new String[]{"Opening","Income","Collection","Expense","Commission","Transfer"})||!allowed(m,modes))throw new Exception("Invalid transaction in backup.");if(k.equals("Transfer")&&(!allowed(t,modes)||m.equals(t)))throw new Exception("Invalid transfer.");if(k.equals("Collection")){if(!amounts.containsKey(bill))throw new Exception("Payment references a missing bill.");payments.put(bill,(payments.containsKey(bill)?payments.get(bill):0)+n);}else if(bill!=0)throw new Exception("Invalid bill reference.");}
        for(Long id:payments.keySet())if(payments.get(id)>amounts.get(id))throw new Exception("Backup contains bill overpayments.");
    }
    void loadBackup(JSONObject root)throws Exception{checkBackup(root);db.beginTransaction();try{db.delete("entries",null,null);db.delete("bills",null,null);for(String table:new String[]{"bills","entries"}){JSONArray arr=root.getJSONArray(table);String[] cols=table.equals("bills")?new String[]{"id","day","customer","note","amount"}:new String[]{"id","day","kind","amount","mode","target","bill","note"};for(int i=0;i<arr.length();i++){JSONObject row=arr.getJSONObject(i);ContentValues cv=new ContentValues();for(String c:cols){if(c.equals("id")||c.equals("amount")||c.equals("bill"))cv.put(c,row.getLong(c));else cv.put(c,row.getString(c));}db.insertOrThrow(table,null,cv);}}db.setTransactionSuccessful();}finally{db.endTransaction();}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null)return;try{Uri uri=data.getData();if(request==BACKUP){byte[] bytes=snapshot().toString(2).getBytes("UTF-8");try(OutputStream s=getContentResolver().openOutputStream(uri,"wt")){if(s==null)throw new Exception("Cannot open backup file.");s.write(bytes);}Toast.makeText(this,"Backup saved. Keep it private.",Toast.LENGTH_LONG).show();}else if(request==RESTORE){ByteArrayOutputStream b=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(uri)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){b.write(buf,0,n);if(b.size()>10000000)throw new Exception("Backup too large (10 MB limit).");}}loadBackup(new JSONObject(b.toString("UTF-8")));home();Toast.makeText(this,"Backup restored",Toast.LENGTH_LONG).show();}}catch(Exception e){error(e);}}
}
